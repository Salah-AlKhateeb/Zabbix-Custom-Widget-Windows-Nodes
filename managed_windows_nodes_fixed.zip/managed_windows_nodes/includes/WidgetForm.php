<?php
// includes/WidgetForm.php

class WidgetForm extends CWidgetForm {

	public function addFields(): self {
		return $this
			->addField(
				(new CWidgetFieldText('partner_tag_key', _('Partner tag key')))
					->setDefault('partern')
			)
			->addField(
				(new CWidgetFieldText('partner_pattern', _('Partner pattern (contains)')))
					->setDefault('ARQ')
			)
			->addField(
				(new CWidgetFieldText('os_tag_key', _('OS tag key')))
					->setDefault('os')
			)
			->addField(
				(new CWidgetFieldText('site_tag_key', _('Site tag key')))
					->setDefault('site')
			)
			->addField(
				new CWidgetFieldMultiSelectGroup('groupids', _('Host groups'))
			)
			->addField(
				(new CWidgetFieldNumber('device_limit', _('Device limit')))
					->setDefault(0)
			);
	}
}
