<?php declare(strict_types = 0);
/*
 * Managed Windows Nodes widget view.
 *
 * @var CView $this
 * @var array $data
 */

if (!empty($data['error'])) {
	echo (new CMessageHelper())->warning(_('Managed Windows Nodes widget error:').' '.$data['error']);
	return;
}

$table = (new CTableInfo())->setHeader([_('Site'), _('Windows nodes')]);

if (empty($data['counts'])) {
	$table->addRow([_('No data'), '0']);
}
else {
	foreach ($data['counts'] as $site => $count) {
		$table->addRow([$site, $count]);
	}
}

echo $table;
echo (new CDiv())
	->addClass('managed-windows-nodes-footer')
	->addItem((new CSpan(_('Total:')))->addClass('managed-windows-nodes-total-label'))
	->addItem(' ')
	->addItem((new CSpan((string) ($data['total'] ?? 0)))->addClass('managed-windows-nodes-total-value'));
