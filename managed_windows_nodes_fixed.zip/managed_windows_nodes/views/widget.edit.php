<?php declare(strict_types = 0);
/*
 * Managed Windows Nodes widget form view.
 *
 * @var CView $this
 * @var array $data
 */

(new CWidgetFormView($data))
	->addField(new CWidgetFieldTextBoxView($data['fields']['partner_tag_key']))
	->addField(new CWidgetFieldTextBoxView($data['fields']['partner_pattern']))
	->addField(new CWidgetFieldTextBoxView($data['fields']['os_tag_key']))
	->addField(new CWidgetFieldTextBoxView($data['fields']['site_tag_key']))
	->addField(new CWidgetFieldMultiSelectGroupView($data['fields']['groupids']))
	->addField(new CWidgetFieldNumberView($data['fields']['device_limit']))
	->show();
