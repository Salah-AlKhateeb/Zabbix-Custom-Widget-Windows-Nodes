<?php
// actions/WidgetView.php

class WidgetView extends CWidgetView {

	private function tagsToMap(array $tags): array {
		$map = [];
		foreach ($tags as $t) {
			if (!array_key_exists('tag', $t)) {
				continue;
			}
			$map[$t['tag']] = $t['value'] ?? '';
		}
		return $map;
	}

	public function doAction() {
		$partner_tag_key = $this->fields_values['partner_tag_key'] ?? 'partern';
		$partner_pattern = $this->fields_values['partner_pattern'] ?? 'ARQ';
		$os_tag_key = $this->fields_values['os_tag_key'] ?? 'os';
		$site_tag_key = $this->fields_values['site_tag_key'] ?? 'site';
		$groupids = $this->fields_values['groupids'] ?? [];
		$limit = isset($this->fields_values['device_limit']) ? (int) $this->fields_values['device_limit'] : 0;

		$data = [
			'counts' => [],
			'total' => 0,
			'error' => null
		];

		try {
			$options = [
				'output' => ['hostid', 'host', 'name'],
				'selectTags' => ['tag', 'value'],
				'preservekeys' => false
			];

			if (!empty($groupids)) {
				$options['groupids'] = $groupids;
			}

			$hosts = API::Host()->get($options);

			foreach ($hosts as $h) {
				$tags = $this->tagsToMap($h['tags'] ?? []);

				$partner_val = $tags[$partner_tag_key] ?? '';
				if ($partner_val === '' || stripos($partner_val, $partner_pattern) === false) {
					continue;
				}

				$os_val = $tags[$os_tag_key] ?? '';
				if ($os_val === '' || stripos($os_val, 'win') === false) {
					continue;
				}

				$site = trim($tags[$site_tag_key] ?? '');
				if ($site === '') {
					$site = 'Unknown';
				}

				if (!array_key_exists($site, $data['counts'])) {
					$data['counts'][$site] = 0;
				}
				$data['counts'][$site]++;
				$data['total']++;

				if ($limit > 0 && $data['total'] >= $limit) {
					break;
				}
			}

			ksort($data['counts'], SORT_NATURAL | SORT_FLAG_CASE);
		}
		catch (Exception $e) {
			$data['error'] = $e->getMessage();
		}

		$this->setResponse(new CControllerResponseData([
			'main_block' => (new CView('widget.view', $data))->getOutput()
		]));
	}
}
