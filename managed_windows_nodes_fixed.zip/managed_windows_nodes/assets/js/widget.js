/**
 * Minimal JS class stub for Zabbix widget module.
 */
class CManagedWindowsWidget extends CWidget {
	onInitialize() {}
	onActivate() {}
	onDeactivate() {}
}
